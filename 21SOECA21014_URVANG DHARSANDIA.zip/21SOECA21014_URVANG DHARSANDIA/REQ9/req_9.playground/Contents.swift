import UIKit

//21SOECA21014
//Urvang Dharsdandia

for i in 1...4{
    
    for j in 1...i{
        
        print("*" , terminator : "")
    }
    print(" ")
}

