import UIKit
import Foundation

//21SOECA21014
//URVANG DHARSANDIA

var flag : Bool = false;
let number : Int = 13;
for i in 2 ... number/2 {
    if(number % i == 0){
        flag = true
        break;
    }
}
if flag == false {
    print("is prime”)
} else {
    print("is not prime”)
}

