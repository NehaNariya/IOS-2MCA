import UIKit


//21SOECA21014
//URVANG DHARSANDIA

var myDict = [101: "ToothBrush", 102: "Pencil", 103: "Eraser", 104: "Duster"]

print(myDict)

