import UIKit


//21SOECA21014
//URVANG DHARSANDIA

var numbers : [Int] = [2, 4, 6, 8]
print("Array: \(numbers)")
