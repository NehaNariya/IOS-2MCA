//
//  ViewController.swift
//  REQ12
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

//21soeca21014
//Urvang Dharsandia

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnAlert(_ sender: Any) {
        
        let alert = UIAlertController(title: "Software Update", message: "Do you want to upgrade the system to iOS 15? .", preferredStyle: .UIAlertAction)
        
        alert.addAction(UIAlertAction(title: "YES", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "MAY BE LATER", style: .default, handler: nil))
        
        self.present(alert,animated: true,completion: nil)
        
        
        
    }
    
    

    }



