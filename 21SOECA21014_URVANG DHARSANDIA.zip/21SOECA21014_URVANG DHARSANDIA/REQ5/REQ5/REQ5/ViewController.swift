//
//  ViewController.swift
//  REQ5
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

//21SOECA21014
//URVANG DHARSANDIA

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var txtname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnprint(_ sender: Any) {
        lblname.text = txtname.text
        lblname.textColor = UIColor.red
    }
    
}

