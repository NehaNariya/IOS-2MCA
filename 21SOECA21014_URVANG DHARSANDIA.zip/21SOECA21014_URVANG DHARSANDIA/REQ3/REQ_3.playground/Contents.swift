import UIKit

//21SOECA21014
//URVANG DHARSANDIA

func area(a:Double) -> Double{
    
    let c:Double = 3.14 * a * a;
    
    return c
    
}

var ans = Double(area(a: 30))

print(ans)
