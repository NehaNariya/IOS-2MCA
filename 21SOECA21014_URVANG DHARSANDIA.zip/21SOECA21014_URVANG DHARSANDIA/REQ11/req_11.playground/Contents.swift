import UIKit

//21SOECA21014
//URVANG DHARSANDIA

define enum

enum Capital {
    
    case Gujarat, Maharashtra
    
}

switch(Capital) {
    
case .Gujarat:
    
    print("Capital is Gandhinagar.")
    
case .Maharashtra:
    
    print("Capital is Mumbai.")
