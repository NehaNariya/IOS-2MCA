import UIKit

//21soeca21014
//urvang dharsandia

var A = 155;
var B = 55;

if A>B {
    print("A is Greater Than B");
}
else{
    print("B is Greater Than A");
}
