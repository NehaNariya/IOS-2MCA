//
//  ViewController.swift
//  REQ20
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

//21SOECA21014
//URVANG DHARSANDIA

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var webview: UIWebView!
    @IBOutlet weak var txturl: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btngo(_ sender: Any) {
        
        let url = URL(string: txturl.text!)
        
        let request = URLRequest(url: url!)
        
        webview.loadRequest(request)
    }
    
}

