//
//  ViewController.swift
//  REQ4
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

//21SOECA21014
//URVANG DHARSANDIA

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var mylbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnHide(_ sender: Any) {
        mylbl.isHidden = true
        
    }
    
    @IBAction func btnShow(_ sender: Any) {
        mylbl.isHidden = false
    }
}

