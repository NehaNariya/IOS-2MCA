import UIKit

//21soeca21014
//Urvang Dharsandia

let num1 = 25;
let num2 = 35;
let num3 = 15;

if(num1>num2 && num1 > num3){
    print("Num1 is greater");
    
}
else if(num2 > num3){
    print("num2 is greater");
}
else{
    print("num3 is greater");
}
