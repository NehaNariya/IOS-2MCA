import UIKit

//21SOECA21014
//URVANG DHARSANDIA

var c = 45;
var F = c + 32;
print(F)
