import UIKit

//21SOECA21014
//URVANG DHARSANDIA

var str = "Urvang"
var str2 = "Urvang"
var str3 = "Urvang"


if(str == str2){
    if(str2 == str3){
       print("String is Equal")
    }
 }


