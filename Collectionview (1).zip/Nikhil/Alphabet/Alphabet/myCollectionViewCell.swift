//
//  myCollectionViewCell.swift
//  Alphabet
//
//  Created by RKU on 28/03/22.
//  Copyright © 2022 com. All rights reserved.
//

import UIKit

class myCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Label: UILabel!
}
