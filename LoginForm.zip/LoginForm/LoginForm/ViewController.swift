//
//  ViewController.swift
//  LoginForm
//
//  Created by R K University on 23/03/22.
//  Copyright © 2022 RKU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myUsername: UITextField!
    
    @IBOutlet var myPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "UID") != nil)
        {
            performSegue(withIdentifier: "iBridge", sender: self)
        }
    }
   

    @IBAction func Submit(_ sender: Any) {
        if (myUsername.text == "NEHA" && myPassword.text == "123")
        {
            UserDefaults.standard.set(myUsername.text!, forKey: "UID")
            UserDefaults.standard.set(myPassword.text!, forKey: "PSW")
            
            performSegue(withIdentifier: "iBridge", sender: self)
        }
    }
}

