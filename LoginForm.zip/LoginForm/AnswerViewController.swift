//
//  AnswerViewController.swift
//  LoginForm
//
//  Created by R K University on 23/03/22.
//  Copyright © 2022 RKU. All rights reserved.
//

import UIKit

class AnswerViewController: UIViewController {

    @IBOutlet var userLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "UID") != nil)
        {
            userLabel.text = "Hello, " + UserDefaults.standard.string(forKey: "UID")!
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
