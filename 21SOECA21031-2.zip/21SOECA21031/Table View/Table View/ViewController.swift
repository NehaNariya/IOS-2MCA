//
//  ViewController.swift
//  Table View
//
//  Created by R K University on 23/03/22.
//  Copyright © 2022 com. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate, {
    
    var list = ["Dhoni","Virat","Yuvraj","Dhawan",]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableView") as! myTableViewCell
        
        cell.listcricketer.text = list[indexPath.row]
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

