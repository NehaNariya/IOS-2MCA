//
//  ViewController.swift
//  Login
//
//  Created by R K University on 23/03/22.
//  Copyright © 2022 R K University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myUsername: UITextField!


    @IBOutlet weak var myPassword: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "uid") != UserDefaults.standard.string(forKey: "username")!=
            UserDefaults.standard.string(forKey: "password"))
        {
            print("username and password are invalid")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Submit(_ sender: Any) {
        if (myUsername.text=="Admin", __,myPassword.text=="123")
        {
            performSegue(withIdentifier: "ibridge", sender: self)
        }
    }

}

