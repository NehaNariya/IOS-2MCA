//Nikhil Nandha
//21SOECA21031


import UIKit

enum Day {
    case GoodMorning, GoodAfternoon, GoodEvening
}

var Eraly = Day.GoodMorning

switch(Eraly) {
case .GoodMorning:
    print("Erly Good Morning")
case .GoodAfternoon:
    print("Half Day It is Good AfterNoon")
case .GoodEvening:
    print("After Noon Good Evening");
}


