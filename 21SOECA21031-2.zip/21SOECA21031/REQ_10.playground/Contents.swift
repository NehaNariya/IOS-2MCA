//Nikhil Nandha
//21SOECA21031


import UIKit

var index = 10

while index < 20 {
    
    print( "Value of index is \(index)")
    
    index = index + 1
    
}
