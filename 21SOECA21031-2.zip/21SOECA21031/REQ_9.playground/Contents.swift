//Nikhil Nandha
//21SOECA21031


import UIKit

var P = 100000;
var R = 1000;
var N = 10;

var I = P*R*N/100;

print(I)
