//
//  ViewController.swift
//  REQ_15
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func play(_ sender: Any) {
        
        let vpath = (try! Bundle.main.path(forResource: "video1", ofType: "mp4"))!
        
        let video_player = AVPlayer(url:URL(fileURLWithPath: vpath))
        
        
        let controller = AVPlayerViewController()
        
        controller.player = video_player
        
        self.present(controller,animated: true,completion: nil)
        
        

    }
    
}

