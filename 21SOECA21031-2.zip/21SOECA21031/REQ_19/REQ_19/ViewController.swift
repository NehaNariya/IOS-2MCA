//
//  ViewController.swift
//  REQ_19
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//


import UIKit



class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    var name = ["MSDhoni","Virat","Rahane","Rishabh Pant","Raydu"]
    
    var jercyno = ["7","18","13","99","11"]
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return name.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        
        cell.name.text = name[indexPath.row]
        
        cell.jercyno.text = jercyno[indexPath.row]

        return cell
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
}

