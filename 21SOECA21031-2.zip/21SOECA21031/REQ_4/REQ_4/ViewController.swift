//
//  ViewController.swift
//  REQ_4
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelname: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    
    @IBAction func btnhide(_ sender: Any) {
        btnhide(labelname.isHidden)
    }
    
    
    @IBAction func btnshow(_ sender: Any) {
        btnshow(labelname.shadowColor)
    }
    
}

