//Nikhil Nandha
//21SOECA21031sss

import UIKit

var a=10;

if a<=0 {
    print("a is Negative")
}
else{
    print("a is Positive")
}
