//Nikhil Nandha
//21SOECA21031


import UIKit

var a = 10;
var b = 5;

var d = a/b;
print(d)

var m = a*b;
print(m)


