//
//  ViewController.swift
//  REQ_20
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let alphabet = [a,b,c,id,e,f]
        // Do any additional setup after loading the view, typically from a nib.
    }


}

