//Nikhil Nandha
//21SOECA21031


import UIKit

var student:[Int:String] = [1:"jaydeep", 2:"Jack", 3:"Arun", 4:"Ravi"]

print( "Value of key = 1 is \(student[1])" )

print( "Value of key = 2 is \(student[2])" )

print( "Value of key = 3 is \(student[3])" )

print( "Value of key = 4 is \(student[4])" )
