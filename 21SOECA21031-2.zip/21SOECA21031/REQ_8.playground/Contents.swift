//Nikhil Nandha
//21SOECA21031


import UIKit

var a = 10;
var b = 20
var c = 30;

if a<b {
    print("a is minimum to b")
}
else if b<c{
    print("b is minimum to c")
}
else{
    print("c is max from all")
}


