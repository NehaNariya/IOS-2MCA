//
//  ViewController.swift
//  REQ_12
//
//  Created by Student on 05/07/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var no1: UITextField!
    @IBOutlet weak var no2: UITextField!
    
    @IBOutlet weak var show: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func plus(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 + no2);
        
        show(plus(total))
        
    }
    
    @IBAction func mines(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 - no2);
        
        show(plus(total))
    }
 
    @IBAction func mul(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 * no2);
        
        show(plus(total))
    }
   
    @IBAction func mod(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 / no2);
        
        show(plus(total))
    }
    
    
    
}

