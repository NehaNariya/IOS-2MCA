//Nikhil Nandha
//21SOECA21031


import UIKit

var str = "Hello"
var str1 = "Hello World"

print(str == str1)
