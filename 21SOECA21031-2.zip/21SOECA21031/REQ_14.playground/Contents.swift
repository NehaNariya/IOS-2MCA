//Nikhil Nandha
//21SOECA21031


import UIKit

enum cities {
    case Rajkot, Pune, Upleta, Chotila
}

var City = cities.Rajkot

switch(City) {
    
case .Rajkot:
    
    print("Very High temp In Rajkot")
    
case .Pune:
    
    print("Almost High temp In Pune")
    
case .Upleta:
    
    print("Medium temp In Upleta");
    
case .Chotila:
    
    print("Same as temp For Rajkot")
    
}


