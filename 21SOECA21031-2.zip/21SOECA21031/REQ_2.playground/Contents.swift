//Nikhil Nandha
//21SOECA21031


import UIKit

var a = 10;
var b = 20;
var c = 30;

if(a>b){
    print("b is greater than a");
}
else if(b>c){
    print("c is greater than b");
}
else {
    print("a is not greater all of");
}

