1.	
Design swift code to convert temp Celsius to Fahrenheit using function with return type.

°C = °F - 32

=>
func main() {
    var choice: String
    
    choice = getChoice()
    switch choice {
        case "C", "c":
            processCelsius()
        case "F", "f":
            processFahrenheit()
        default:
            print("You must enter C to convert to Celsius or F to convert to Fahrenheit.")
    }
}

&&

var c = 45;
var F = c + 32;
print(F)

----------
2.
	
Write a swift program to find largest number from two numbers.
=>
import Swift

var num1:Int=5
var num2:Int=10
var large:Int=0

large=max(num1,num2)

print("Largest number is: ",large)

&&

var A = 155;
var B = 55;

if A>B {
    print("A is Greater Than B");
}
else{
    print("B is Greater Than A");
}

&&

var x = 100
var y = 200
var z = 30

if(x < y && x < z)
{
    print("X is min")
}
if(y < x && y < z)
{
    print("Y is min")
}
if(z < y && z < x)
{
    print("Z is min")
}


----------------
3.
	
Write a swift program to create function with return value for calculating area of circle.

=>

func area(a:Double) -> Double{
    
    let c:Double = 3.14 * a * a;
    
    return c
    
}

var ans = Double(area(a: 30))

print(ans)

------------

4.
Develop an iOS application using UIButton and UILabel in which take a two UIButtons as “hide” and “show” and change UILabel visibility accordingly.

=>

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var mylbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnHide(_ sender: Any) {
        mylbl.isHidden = true
        
    }
    
    @IBAction func btnShow(_ sender: Any) {
        mylbl.isHidden = false
    }
}

------


REQ_ 5

Design and Develop iOS application to take name form user and printthat name into UILabel. Create UIControls according to need. UILabelfont color should be red do it using coding only.

=>
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var txtname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnprint(_ sender: Any) {
        lblname.text = txtname.text
        lblname.textColor = UIColor.red
    }
    
}

------
REQ_ 6

Write a swift program to find prime – non-prime number

=>

var flag = 0
var n:Int = 3

for i in 2...n-1
{
    if(n%i == 0)
    {
        flag = 1
    }
}

if(flag == 1)
{
    print("\(n) Number is Non-Prime")
}
else
{
    print("\(n) Number is Prime")
}

&&

import UIKit

var flag=0
var n = 13

var i = 2
for i in 2 ... n-1
{
    if(n%i==0)
    {
        flag = 1;
        break;
    }
}

if(flag==1)
{
    print("\(n)" + " is not prime")
}
else
{
    print("\(n)" + " is  prime")

}


&&

&&

var flag : Bool = false;
let number : Int = 13;
for i in 2 ... number/2 {
    if(number % i == 0){
        flag = true
        break;
    }
}
if flag == false {
    print("is prime”)
} else {
    print("is not prime”)
}


--
REQ_ 7

Write a swift program to compare three strings.

=>

var str = "Urvang"
var str2 = "Urvang"
var str3 = "Urvang"


if(str == str2){
    if(str2 == str3){
       print("String is Equal")
    }
 }
------------

REQ_ 8

Create a swift program to find maximum value from given three variables.

=>
let first = 10
let second = 15
let third = 18

let largest = max(first, second, third)

&&

let first = 10
let second = 15
let third = 18

let smallest = min(min(first, second), third)

&&


let num1 = 25;
let num2 = 35;
let num3 = 15;

if(num1>num2 && num1 > num3){
    print("Num1 is greater");
    
}
else if(num2 > num3){
    print("num2 is greater");
}
else{
    print("num3 is greater");
}


------


 

REQ _ 9

Create a swift program to print following using for-loop.

*

**

***

****

=>

for i in 1...4{
    
    for j in 1...i{
        
        print("*" , terminator : "")
    }
    print(" ")
}

&&



---

REQ_ 10

Create a swift array and print whole array using swift while loop only.
=>

var numbers : [Int] = [2, 4, 6, 8]
print("Array: \(numbers)")

&&

**main.swift

var primes:[Int] = [2, 3, 5, 7, 11]
 
var i=0
 
while i<primes.count {
    print("\(primes[i])")
}

**Output

2
3
5
7
11

----

REQ_ 11

Create a swift program to show the capitals of different cities using Enumerations.

=>

enum Climate {
   case India
   case America
   case Africa
   case Australia
}

var season = Climate.America
season = .America
switch season {
   case .India:
      print("Climate is Hot")
   case .America:
      print("Climate is Cold")
   case .Africa:
      print("Climate is Moderate")
   case .Australia:
      print("Climate is Rainy")
   
}

**o/p

Climate is Cold

&&


define enum

enum Capital {
    
    case Gujarat, Maharashtra
    
}

switch(Capital) {
    
case .Gujarat:
    
    print("Capital is Gandhinagar.")
    
case .Maharashtra:
    
    print("Capital is Mumbai.")


&&


enum names {
   case Swift
   case Closures
}

var lang = names.Closures
lang = .Closures

switch lang {
   case .Swift:
      print("Welcome to Swift")
   case .Closures:
      print("Welcome to Closures")
   default:
      print("Introduction")
}

---



 

 

REQ_12

Create an iOS project to present UIAlertController to show the following parameters.

a.  Title : Gender

b.  Message : Please select your gender.

c.  Buttons : Male & Female.

=>

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnAlert(_ sender: Any) {
        
        let alert = UIAlertController(title: "Software Update", message: "Do you want to upgrade the system to iOS 15? .", preferredStyle: .UIAlertAction)
        
        alert.addAction(UIAlertAction(title: "YES", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "MAY BE LATER", style: .default, handler: nil))
        
        self.present(alert,animated: true,completion: nil)   
    }
}


&&

//UIImageView and Alert Controller
 
//
//  ViewController.swift
//  ImageAlert
//
//  Created by Dhaval on 14/03/22.
//

import UIKit
 
class ViewController: UIViewController {
 
    //Create outlets here
    
    @IBOutlet weak var myImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //to show static image from project dir
        myImage.image = UIImage(named: "hack.jpg")
    }
 
    //Create Actions here
    @IBAction func submit(_ sender: Any) {
        //click event for submit
        
        let alert = UIAlertController(title: "Warning", message: "Do you want to load image from URL?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {
            ACTION in
            self.change_image()
        }))
        alert.addAction(UIAlertAction(title: "No", style: .destructive, handler: nil))
        self.present(alert,animated: true,completion: nil)
        
    }
    
    func change_image()
    {
        //OPEN Image from URL
        let imgURL = URL(string: "https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-dallas-shootings-don-add-are-speech-zones-used-4.png")
        let imgData = try! Data(contentsOf: imgURL!)
        myImage.image = UIImage(data: imgData)
    }
}
 

-----

REQ_ 13

Create an iOS project with following parameters along with required outlets and actions

Note : You may apply your own font style, colours and images. And also avoid imageview.

=>
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

----


 

REQ_ 14

Create an iOS project to present the following tabs using UITabBarController and UINavigationController.

1.     Home

2.     Watch

3.     Profile

4.    Notification

=>

tab bar Controller & navigation bar Controller levu aama

tab bar Controller ma right click kari ne view Controller ma lay java nu pa6i tema view Controller no
option aavse tema click karvu

*tab bar Controller mathi same option ma 4tha number na option ma javu niche tir jevu hase tema
* tema view Controller no option hase
* tema title ni niche "is initial view controller" ma tick kari destructive*
*

---


REQ_ 15

Create a swift program to store the values of following students using Dictionary.

Key - Value

101  ToothBrush

102  Pencil

103  Eraser

104  Duster

=>

var myDict = [101: "ToothBrush", 102: "Pencil", 103: "Eraser", 104: "Duster"]

print(myDict)

&&
//Dictionary
var someDict:[Int:String] = [1:"One", 2:"Two", 3:"Three"]


----


REQ_ 16

Download following iOS Project and complete the missing code or solve appropriate errors to present UITableView

Project --> Table View.zipView in a new window
=>

import UIKit

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource{
    
    var list = ["Dhoni","Virat","Yuvraj","Dhawan",]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
       return list.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        
        cell.lblname.text = list[indexPath.row]
        
        return cell

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


&&

import UIKit
 
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    var listImage = ["https://media.zigcdn.com/media/model/2021/Nov/amg-a45-5_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-glc-43_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-e-63_360x240.jpg","https://media.zigcdn.com/media/model/2021/Aug/amg-gle-63_360x240.jpg"]
    var listTitle = ["Mercedes-Benz AMG A45 S","Mercedes-Benz AMG GLC 43","Mercedes-Benz AMG E 63","Mercedes-Benz AMG GLE 63 S"]
    var listPrice = ["Rs. 79.50 Lakh","Rs. 85.40 Lakh","Rs. 1.73 Crore","Rs. 2.10 Crore"]
    
   // var imgArray = ["1.jpg","2.jpg","3.jpg","4.jpg"]
    
    // No of items/rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTitle.count
    }
    
    // value of each item
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        cell.CarName.text = listTitle[indexPath.row]
        cell.CarPrice.text = listPrice[indexPath.row]
        let iurl = URL(string: listImage[indexPath.row])
        let request = try! Data(contentsOf: iurl!)
        cell.myImage.image = UIImage(data: request)
        
        //cell.myImage.image = UIImage(named: imgArray[indexPath.row])
        return cell
    }
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

-----


REQ_ 17

Download following iOS Project and complete the missing code or solve appropriate errors to Store the values of user id 
andpassword using UserDefaults.

Project --> Login.zipView in a new window
=>

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myUsername: UITextField!


    @IBOutlet weak var myPassword: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "uid") != )
        {
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Submit(_ sender: Any) {
        if (myUsername.text=="Admin" && myPassword.text=="123")
        {
            performSegue(withIdentifier: "ibridge", sender: self)
        }
    }

}

&&

import UIKit
import Parse

class ViewController: UIViewController {
    
    @IBOutlet weak var txtUsernameSignin: UITextField!
    @IBOutlet weak var txtPasswordSignin: UITextField!
    @IBOutlet weak var indicatorSignin: UIActivityIndicatorView!
    
    @IBOutlet weak var txtUsernameSignup: UITextField!
    @IBOutlet weak var txtPasswordSignup: UITextField!
    @IBOutlet weak var indicatorSignup: UIActivityIndicatorView!
    
    @IBOutlet weak var btnLogout: UIButton!
    
   override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func signin(_ sender: Any) {
        PFUser.logInWithUsername(inBackground: self.txtUsernameSignin.text!, password: self.txtPasswordSignin.text!) {
          (user: PFUser?, error: Error?) -> Void in
          if user != nil {
            self.displayAlert(withTitle: "Login Successful", message: "")
          } else {
            self.displayAlert(withTitle: "Error", message: error!.localizedDescription)
          }
        }
    }
    
    @IBAction func signup(_ sender: Any) {
        let user = PFUser()
        user.username = self.txtUsernameSignup.text
        user.password = self.txtPasswordSignup.text
        
        self.indicatorSignup.startAnimating()
        user.signUpInBackground {(succeeded: Bool, error: Error?) -> Void in
            self.indicatorSignup.stopAnimating()
            if let error = error {
                self.displayAlert(withTitle: "Error", message: error.localizedDescription)
            } else {
                self.displayAlert(withTitle: "Success", message: "Account has been successfully created")
            }
        }
    }
    
    @IBAction func logout(_ sender: Any) {
        PFUser.logOut()
    }
    
    func displayAlert(withTitle title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default)
        alert.addAction(okAction)
        self.present(alert, animated: true)
    }
    
}

-------



 

REQ_ 18

Create an iOS project to present UIAlertController to show the following parameters.

Preferred Style must be action sheet Title : Software Update

Message : Do you want to upgrade the system to iOS 15? Buttons : Yes & No & May be later
=>

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnAlert(_ sender: Any) {
        
        let alert = UIAlertController(title: "Gender", message: "Please select your gender.", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Male", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Female", style: .default, handler: nil))
        
        self.present(alert,animated: true,completion: nil)
    }
}
 

&&

import UIKit
 
class ViewController: UIViewController {
 
    //Create outlets here
    
    @IBOutlet weak var myImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //to show static image from project dir
        myImage.image = UIImage(named: "hack.jpg")
    }
 
    //Create Actions here
    @IBAction func submit(_ sender: Any) {
        //click event for submit
        
        let alert = UIAlertController(title: "Warning", message: "Do you want to load image from URL?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {
            ACTION in
            self.change_image()
        }))
        alert.addAction(UIAlertAction(title: "No", style: .destructive, handler: nil))
        self.present(alert,animated: true,completion: nil)
        
    }
    
    func change_image()
    {
        //OPEN Image from URL
        let imgURL = URL(string: "https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-dallas-shootings-don-add-are-speech-zones-used-4.png")
        let imgData = try! Data(contentsOf: imgURL!)
        myImage.image = UIImage(data: imgData)
    }
}
 
------------------


REQ_19

Create an iOS project to demonstrate simple table view. Prepare list of different birds names only
=>

import UIKit



class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    var list = ["Peacock","Sparrow"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        
        cell.lblname.text = list[indexPath.row]

        return cell

    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}


&&&&

import UIKit
 
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    var listImage = ["https://media.zigcdn.com/media/model/2021/Nov/amg-a45-5_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-glc-43_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-e-63_360x240.jpg","https://media.zigcdn.com/media/model/2021/Aug/amg-gle-63_360x240.jpg"]
    var listTitle = ["Mercedes-Benz AMG A45 S","Mercedes-Benz AMG GLC 43","Mercedes-Benz AMG E 63","Mercedes-Benz AMG GLE 63 S"]
    var listPrice = ["Rs. 79.50 Lakh","Rs. 85.40 Lakh","Rs. 1.73 Crore","Rs. 2.10 Crore"]
    
   // var imgArray = ["1.jpg","2.jpg","3.jpg","4.jpg"]
    
    // No of items/rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTitle.count
    }
    
    // value of each item
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        cell.CarName.text = listTitle[indexPath.row]
        cell.CarPrice.text = listPrice[indexPath.row]
        let iurl = URL(string: listImage[indexPath.row])
        let request = try! Data(contentsOf: iurl!)
        cell.myImage.image = UIImage(data: request)
        
        //cell.myImage.image = UIImage(named: imgArray[indexPath.row])
        return cell
    }
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

-------------



REQ_20

Create an iOS project to open a given URL using WebView.

www.apple.com.
=>

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var webview: UIWebView!
    @IBOutlet weak var txturl: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btngo(_ sender: Any) {
        
        let url = URL(string: txturl.text!)
        
        let request = URLRequest(url: url!)
        
        webview.loadRequest(request)
    }
    
}


&&&

import UIKit
import WebKit
class ViewController: UIViewController, WKUIDelegate {
    
    var webView: WKWebView!
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let myURL = URL(string:"https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }}

&&&&&&

As an iOS developer, you will come across multiple scenarios where you have to display something in web, for that we use WebView.

As per Apple, − It is an object that displays interactive web content, such as for an in-app browser.

So in this post, we will be seeing how to create WebView and load the data in it.

So let’s start

Step 1 − Open Xcode and create a single view application and name it WebViewSample.

Step 2 − Open ViewController.swift file and import the WebKit module. import WebKit

Step 3 − Add a property of WebKit in ViewController.swift.

var webView: WKWebView!
Step 4 − Add WKUIDelegate delegate to ViewController.swift

Step 5 − In ViewController.swift add the below method, add override loadView function.

override func loadView() {
   let webConfiguration = WKWebViewConfiguration()
   webView = WKWebView(frame: .zero, configuration: webConfiguration)
   webView.uiDelegate = self
   view = webView
}
Step 6 − In viewDidLoad create the URL request which you want to load and load the URL

override func viewDidLoad() {
   super.viewDidLoad()
   let myURL = URL(string:"https://www.apple.com")
   let myRequest = URLRequest(url: myURL!)
   webView.load(myRequest)
}
Step 7 − Run the application,

Complete code

import UIKit
import WebKit
class ViewController: UIViewController, WKUIDelegate {
   var webView: WKWebView!
   override func viewDidLoad() {
      super.viewDidLoad()
      let myURL = URL(string:"https://www.apple.com")
      let myRequest = URLRequest(url: myURL!)
      webView.load(myRequest)
   }
   override func loadView() {
      let webConfiguration = WKWebViewConfiguration()
      webView = WKWebView(frame: .zero, configuration: webConfiguration)
      webView.uiDelegate = self
      view = webView
   }
}
--------------------------------------------

 
 