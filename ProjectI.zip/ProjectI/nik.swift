REQ_ 1

Write a swift program to create calculator functions such as division, multiplication with return type.
=>
import UIKit

var a = 10;
var b = 5;

var d = a/b;
print(d)

var m = a*b;
print(m)

-------

REQ_ 2

Write a swift program to find largest number from given three numbers.
=>

var x = 100
var y = 200
var z = 30

if(x < y && x < z)
{
    print("X is min")
}
if(y < x && y < z)
{
    print("Y is min")
}
if(z < y && z < x)
{
    print("Z is min")
}

&&&&&&

import UIKit

var a = 10;
var b = 20;
var c = 30;

if(a>b){
    print("b is greater than a");
}
else if(b>c){
    print("c is greater than b");
}
else {
    print("a is not greater all of");
}
--------------
REQ_ 3

Write a swift program to create function with return value for wishing good morning.

=>
import UIKit

enum Day {
    case GoodMorning, GoodAfternoon, GoodEvening
}

var Eraly = Day.GoodMorning

switch(Eraly) {
case .GoodMorning:
    print("Erly Good Morning")
case .GoodAfternoon:
    print("Half Day It is Good AfterNoon")
case .GoodEvening:
    print("After Noon Good Evening");
}

------------------
REQ_ 4

Develop an iOS application using UIButton and UILabel in which take a two UIButtons as “hide” and “show” and change UILabel visibility accordingly.
=>

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelname: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    
    @IBAction func btnhide(_ sender: Any) {
        btnhide(labelname.isHidden)
    }
    
    
    @IBAction func btnshow(_ sender: Any) {
        btnshow(labelname.shadowColor)
    }
    
}

----------------------

REQ_ 5

Design and Develop iOS application to take name form user and print that name into UILabel. 
Create UIControls according to need. UILabel font color should be red do it using coding only.
=>

--------

REQ_ 6

Write a swift program to number is positive or negative or zero.
=>
import UIKit

var a=10;

if a<=0 {
    print("a is Negative")
}
else{
    print("a is Positive")
}

&&&

func test_num(x: Int, y: Int) -> Bool {
    if x > 0 && y < 0 
    {
        return true
    }
    else if x < 0 && y > 0 
    {
        return true
    } 
    else if x < 0 && y < 0 
    {
        return true
    } 
    else
    {
        return false
    }
}

print(test_num(x:12, y:-5))
print(test_num(x:-12, y:5))
print(test_num(x:-12, y:-5))
print(test_num(x:12, y:5))

-----------------

REQ_ 7

Write a swift program to compare 2 strings.
=>

import UIKit

var str = "Hello"
var str1 = "Hello World"

print(str == str1)


&&&

let password = "HelloWorld"
let repeatPassword = "HelloWorld"
if ((password.elementsEqual(repeatPassword)) == true)
{
   print("Passwords are equal")
} else {
   print("Passwords are not equal")
}

&&&

let valueExpected = "SUCCESS"
let valueProvided = "success"
if valueExpected.caseInsensitiveCompare(valueProvided) == ComparisonResult.orderedSame
{
    print("Strings are equal")
}
-------------

REQ_ 8

Create a swift program to find minimum value from given three variables.
=>
import UIKit

var a = 10;
var b = 20
var c = 30;

if a<b {
    print("a is minimum to b")
}
else if b<c{
    print("b is minimum to c")
}
else{
    print("c is max from all")
}

---------------------

REQ _ 9

Create a swift program to find interest of given principle. (I=PRN/100)

=>
import UIKit

var P = 100000;
var R = 1000;
var N = 10;

var I = P*R*N/100;

print(I)

&&&&&&&&&&

import Foundation
//  Swift program for
//  Calculate simple interest
class Interest
{
    // Method which is take three parameters
    // And calculates that simple interest
    // Here time is form in year
    // rate is form of annual interest rate
    static func simpleInterest(_ principle : Double, 
                               _ time : Double, 
                               _ rate : Double)
    {
        // Display parameters values
        print("Principal : ",principle);
        print("Time : ",time);
        print("Rate : ",rate);
        // Calculate interest
        let amount : Double = (principle * time * rate) / 100;
        // Display amount
        print("Simple Interest : ",amount);
    }
}

 // Test Cases
Interest.simpleInterest(1500,3,7.3);
Interest.simpleInterest(170.4,7,3.4);
Output

Principal :  1500.0
Time :  3.0
Rate :  7.3
Simple Interest :  328.5
Principal :  170.4
Time :  7.0
Rate :  3.4
Simple Interest :  40.5552

------------------
REQ_ 10

Create a swift array and print whole array using swift while loop.
=>


import UIKit

var index = 10

while index < 20 {
    
    print( "Value of index is \(index)")
    
    index = index + 1
    
}

----------------

REQ_ 11

Create a swift program to store the values of following students using Dictionary.

 

Roll No - Name

1                  Jaydeep

2                  Jack

3                  Arun

4               Ravi
=>
import UIKit

var student:[Int:String] = [1:"jaydeep", 2:"Jack", 3:"Arun", 4:"Ravi"]

print( "Value of key = 1 is \(student[1])" )

print( "Value of key = 2 is \(student[2])" )

print( "Value of key = 3 is \(student[3])" )

print( "Value of key = 4 is \(student[4])" )

-----------------

REQ_12
Create an iOS project with following parameters along with required outlets and actions.

Note : You may apply your own font style, colours and images.
=>

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var no1: UITextField!
    @IBOutlet weak var no2: UITextField!
    
    @IBOutlet weak var show: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func plus(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 + no2);
        
        show(plus(total))
        
    }
    
    @IBAction func mines(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 - no2);
        
        show(plus(total))
    }
 
    @IBAction func mul(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 * no2);
        
        show(plus(total))
    }
   
    @IBAction func mod(_ sender: Any) {
        
        let no1 = self.no1;
        let no2 = self.no2;
        
        let total = self(no1 / no2);
        
        show(plus(total))
    }   
}


&&&&&&&&&&&&&&&&&&&&&&&&&&&

Addition (SUM)
//
// ViewController.swift
// Addtion
//
// Created by R K University on 15/04/22.
// Copyright © 2022 RKU. All rights reserved.
//
import UIKit
class ViewController: UIViewController {
var res:Int = 0;
@IBOutlet var txt1: UITextField!
@IBOutlet var txt2: UITextField!
@IBOutlet var lblres: UILabel!

@IBAction func btnsum(_ sender: Any) {
res = Int(txt1.text!)! + Int(txt2.text!)!
lblres.text = String(res);
}
override func viewDidLoad() {
super.viewDidLoad()
// Do any additional setup after loading the view, typically from a nib.
}
override func didReceiveMemoryWarning() {
super.didReceiveMemoryWarning()
// Dispose of any resources that can be recreated.
}

}
-------------------
 

REQ_ 13

Create an iOS project to present the following tabs using UITabBarController and UINavigationController.

1.     Chat

2.     Phone

3.     Keypad

4.     Voice Mail
=>
tab bar Controller & view Controller levu

------------------
REQ_ 14

Create a swift program to show the population of different Indian cities using Enumerations.
=>

import UIKit

enum cities {
    case Rajkot, Pune, Upleta, Chotila
}

var City = cities.Rajkot

switch(City) {
    
case .Rajkot:
    
    print("Very High temp In Rajkot")
    
case .Pune:
    
    print("Almost High temp In Pune")
    
case .Upleta:
    
    print("Medium temp In Upleta");
    
case .Chotila:
    
    print("Same as temp For Rajkot")
    
}


--------------------------
REQ_ 15

Create an iOS project to play video or audio from specific URL.

Note : specify any random URL for audio or video and complete the code.
=>
//Audio Player – with CollectionView
//  ViewController.swift
//  MeditationPlayer|
import UIKit
import AVKit
import AVFoundation
 
class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    @IBOutlet weak var thumbnilImg: UIImageView!
    @IBOutlet weak var shortView: UILabel!
    
    @IBOutlet weak var SongName: UILabel!
    @IBOutlet weak var myView: UIView!
    var titleList = ["Harmony to Life","Meditation","Sound of Bird","Positive Energy"]
    var imgList = ["hm.jpg","meditation.jpg","pe.jpg","positiveenergy.jpg"]
    var mp3List = ["hm","meditation","pe","positiveenergy"]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! myCollectionCell
        cell.myImage.image = UIImage(named: imgList[indexPath.row])
        cell.myImage.layer.cornerRadius = cell.myImage.frame.width / 2
        return cell
        
    }
    var player:AVAudioPlayer?
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var selectedindex = indexPath.row
        print(selectedindex)
        
        let mp3Path = Bundle.main.path(forResource: mp3List[indexPath.row], ofType: "mp3")
        player = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: mp3Path!))
        
        if player!.isPlaying == false
        {
            SongName.text = titleList[indexPath.row]
            thumbnilImg.image = UIImage(named:imgList[selectedindex])
            thumbnilImg.layer.cornerRadius = 16
            player!.prepareToPlay()
            player!.play()
            myView.isHidden = false
        }else
        {
            myView.isHidden = true
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        myView.isHidden = true
        player?.stop()
    }
    @IBAction func pause(_ sender: Any) {
        if (player?.isPlaying == true)
        {
            player?.pause()
        }
    }
    
    @IBAction func stop(_ sender: Any) {
        if (player?.isPlaying == true)
        {
            player?.stop()
            player?.prepareToPlay()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        myView.isHidden = true
        myView.layer.cornerRadius = 15
        myView.backgroundColor = UIColor(red: 120/255, green: 120/255, blue: 120/255, alpha: 0.5)
        myView.layer.shadowColor = CGColor(red: 11/255, green: 11/255, blue: 11/255, alpha: 1)
        myView.layer.shadowOffset = CGSize(width: 0, height: 2)
    }
 
 
}
//Video Player Online/Offline
//  ViewController.swift
//  VideoPlayer(Online)
import UIKit
import AVKit
import AVFoundation
 
class ViewController: UIViewController {
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
 
    @IBAction func playVideo(_ sender: Any) {
        //import AVKit
        //import AVFoundation
        //Online
        /*let vUrl = URL(string: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/1080/Big_Buck_Bunny_1080_10s_5MB.mp4")
        
        let video_player = AVPlayer(url: vUrl!)
        
        let controller = AVPlayerViewController()
        
        controller.player = video_player
        
        self.present(controller,animated: true,completion: nil)
        */
        //Offline
        
        let vpath = (try! Bundle.main.path(forResource: "video1", ofType: "mp4"))!
        
        let video_player = AVPlayer(url:URL(fileURLWithPath: vpath))
        
        let controller = AVPlayerViewController()
        
        controller.player = video_player
        
        self.present(controller,animated: true,completion: nil)
            
        }
        
}

&&&&&&&&&&&&&&&&&&&&&&&

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func play(_ sender: Any) {
        
        let vpath = (try! Bundle.main.path(forResource: "video1", ofType: "mp4"))!
        
        let video_player = AVPlayer(url:URL(fileURLWithPath: vpath))
        
        
        let controller = AVPlayerViewController()
        
        controller.player = video_player
        
        self.present(controller,animated: true,completion: nil)
        
        

    }
    
}



------------------------



REQ_ 16

Download following iOS Project and complete the missing code

 or solve appropriate errors to present UITableView.. 

Project --> Table View.zipView in a new window

=>

//TableView
 
import UIKit
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var listImage = ["https://media.zigcdn.com/media/model/2021/Nov/amg-a45-5_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-glc-43_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-e-63_360x240.jpg","https://media.zigcdn.com/media/model/2021/Aug/amg-gle-63_360x240.jpg"]
    var listTitle = ["Mercedes-Benz AMG A45 S","Mercedes-Benz AMG GLC 43","Mercedes-Benz AMG E 63","Mercedes-Benz AMG GLE 63 S"]
    var listPrice = ["Rs. 79.50 Lakh","Rs. 85.40 Lakh","Rs. 1.73 Crore","Rs. 2.10 Crore"]
   // var imgArray = ["1.jpg","2.jpg","3.jpg","4.jpg"]
    // No of items/rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTitle.count
    }
    // value of each item
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        cell.CarName.text = listTitle[indexPath.row]
        cell.CarPrice.text = listPrice[indexPath.row]
        let iurl = URL(string: listImage[indexPath.row])
        let request = try! Data(contentsOf: iurl!)
        cell.myImage.image = UIImage(data: request)
        
        //cell.myImage.image = UIImage(named: imgArray[indexPath.row])
        return cell
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}


&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


import UIKit

class ViewController: UIViewController,UITableViewDelegate, {
    
    var list = ["Dhoni","Virat","Yuvraj","Dhawan",]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableView") as! myTableViewCell
        
        cell.listcricketer.text = list[indexPath.row]
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


---------------------------

REQ_ 17

Download following iOS Project and complete the missing code or solve appropriate errors to Store the values of user id andpassword using UserDefaults 4Marks

Project -->Login.zipView in a new window
=>
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myUsername: UITextField!


    @IBOutlet weak var myPassword: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "uid") != UserDefaults.standard.string(forKey: "username")!=
            UserDefaults.standard.string(forKey: "password"))
        {
            print("username and password are invalid")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Submit(_ sender: Any) {
        if (myUsername.text=="Admin", __,myPassword.text=="123")
        {
            performSegue(withIdentifier: "ibridge", sender: self)
        }
    }

}
&&&&&&&&&&&&&&&&&&&&&&&&&&&

import UIKit

class ViewController: UIViewController {

    @IBOutlet var myUsername: UITextField!
    
    @IBOutlet var myPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.string(forKey: "UID") != nil)
        {
            performSegue(withIdentifier: "iBridge", sender: self)
        }
    }
   

    @IBAction func Submit(_ sender: Any) {
        if (myUsername.text == "NEHA" && myPassword.text == "123")
        {
            UserDefaults.standard.set(myUsername.text!, forKey: "UID")
            UserDefaults.standard.set(myPassword.text!, forKey: "PSW")
            
            performSegue(withIdentifier: "iBridge", sender: self)
        }
    }
}



&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

import UIKit
import Parse

class ViewController: UIViewController {
    
    @IBOutlet weak var txtUsernameSignin: UITextField!
    @IBOutlet weak var txtPasswordSignin: UITextField!
    @IBOutlet weak var indicatorSignin: UIActivityIndicatorView!
    
    @IBOutlet weak var txtUsernameSignup: UITextField!
    @IBOutlet weak var txtPasswordSignup: UITextField!
    @IBOutlet weak var indicatorSignup: UIActivityIndicatorView!
    
    @IBOutlet weak var btnLogout: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func signin(_ sender: Any) {
        PFUser.logInWithUsername(inBackground: self.txtUsernameSignin.text!, password: self.txtPasswordSignin.text!) {
          (user: PFUser?, error: Error?) -> Void in
          if user != nil {
            self.displayAlert(withTitle: "Login Successful", message: "")
          } else {
            self.displayAlert(withTitle: "Error", message: error!.localizedDescription)
          }
        }
    }
    
    @IBAction func signup(_ sender: Any) {
        let user = PFUser()
        user.username = self.txtUsernameSignup.text
        user.password = self.txtPasswordSignup.text
        
        self.indicatorSignup.startAnimating()
        user.signUpInBackground {(succeeded: Bool, error: Error?) -> Void in
            self.indicatorSignup.stopAnimating()
            if let error = error {
                self.displayAlert(withTitle: "Error", message: error.localizedDescription)
            } else {
                self.displayAlert(withTitle: "Success", message: "Account has been successfully created")
            }
        }
    }
    
    @IBAction func logout(_ sender: Any) {
        PFUser.logOut()
    }
    
    func displayAlert(withTitle title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default)
        alert.addAction(okAction)
        self.present(alert, animated: true)
    }
    
}
---------------------------------

REQ_ 18

Create an iOS project to present UIAlertController to show the following parameters.

Preferred Style must be action sheet Title : Software Update

Message : Do you want to upgrade the system to iOS 15? Buttons : Yes & No & May be later
=>
//UIImageView and Alert Controller
//  ImageAlert
import UIKit
class ViewController: UIViewController {
    //Create outlets here
    @IBOutlet weak var myImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //to show static image from project dir
        myImage.image = UIImage(named: "hack.jpg")
    }
    //Create Actions here
    @IBAction func submit(_ sender: Any) {
        //click event for submit
        let alert = UIAlertController(title: "Warning", message: "Do you want to load image from URL?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {
            ACTION in
            self.change_image()
        }))
        alert.addAction(UIAlertAction(title: "No", style: .destructive, handler: nil))
        self.present(alert,animated: true,completion: nil)   
    }   
    func change_image()
    {
        //OPEN Image from URL
        let imgURL = URL(string: "https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-dallas-shootings-don-add-are-speech-zones-used-4.png")
        let imgData = try! Data(contentsOf: imgURL!)
        myImage.image = UIImage(data: imgData)
    }
}
------------------------

REQ_19

Create an iOS project to demonstrate simple table view. Prepare list of different cricket teams.
=>
//TableView
 
//
//  ViewController.swift
//  Car Table List
//
//  Created by Dhaval on 01/04/22.
//
 
import UIKit
 
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    var listImage = ["https://media.zigcdn.com/media/model/2021/Nov/amg-a45-5_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-glc-43_360x240.jpg","https://media.zigcdn.com/media/model/2021/Sep/amg-e-63_360x240.jpg","https://media.zigcdn.com/media/model/2021/Aug/amg-gle-63_360x240.jpg"]
    var listTitle = ["Mercedes-Benz AMG A45 S","Mercedes-Benz AMG GLC 43","Mercedes-Benz AMG E 63","Mercedes-Benz AMG GLE 63 S"]
    var listPrice = ["Rs. 79.50 Lakh","Rs. 85.40 Lakh","Rs. 1.73 Crore","Rs. 2.10 Crore"]
    
   // var imgArray = ["1.jpg","2.jpg","3.jpg","4.jpg"]
    
    // No of items/rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTitle.count
    }
    
    // value of each item
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        cell.CarName.text = listTitle[indexPath.row]
        cell.CarPrice.text = listPrice[indexPath.row]
        let iurl = URL(string: listImage[indexPath.row])
        let request = try! Data(contentsOf: iurl!)
        cell.myImage.image = UIImage(data: request)
        
        //cell.myImage.image = UIImage(named: imgArray[indexPath.row])
        return cell
    }
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
 
 
}

&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&



import UIKit



class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    var name = ["MSDhoni","Virat","Rahane","Rishabh Pant","Raydu"]
    
    var jercyno = ["7","18","13","99","11"]
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return name.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell") as! myTableViewCell
        
        cell.name.text = name[indexPath.row]
        
        cell.jercyno.text = jercyno[indexPath.row]

        return cell
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
}


 ------------------------
 REQ_20

Create an iOS project to demonstrate collection view. Prepare alphabet list ABCD only.
=>

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    let list=["A","B","C"]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return list.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "mycell", for: indexPath) as!
        myCollectionViewCell
        cell.Label.text=list[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
--------------------------------------
------------------------------------
------------------
//Design swift code to convert temp Celsius to Fahrenheit using function with return type. °C = °F - 32
func getChoice() -> String {
    var choice: String

    print("Enter C to convert to Celsius or F to convert to Fahrenheit:")
    choice = readLine(strippingNewline: true)!

    return choice
}


//Write a swift program to find largest number from two numbers.
import Swift

var num1:Int=5
var num2:Int=10
var large:Int=0

large=max(num1,num2)

print("Largest number is: ",large)


//Write a swift program to create function with return value for calculating area of circle.
func addNumbers(a: Int, b: Int) {
  var sum = a + b
  print("Sum:", sum)
}

addNumbers(a: 2, b: 3)


//Write a swift program to find prime – non-prime number
import UIKit

var flag=0
var n = 13

var i = 2
for i in 2 ... n-1
{
    if(n%i==0)
    {
        flag = 1;
        break;
    }
}

if(flag==1)
{
    print("\(n)" + " is not prime")
}
else
{
    print("\(n)" + " is  prime")

}


//Write a swift program to compare three strings.
var str1 = "mango"
var str2 = "apple"
 
if (str1 > str2) {
    print("\(str1) is greater than \(str2)")
} else {
    print("\(str1) is not greater than \(str2)")
}


//Create a swift program to find maximum value from given three variables.
let first = 10
let second = 15
let third = 18

let largest = max(first, second, third)


//pattern
for i in stride(from: 1, to: 5, by: 1) {
   // prints from 1 to 4
    for j in stride(from: 1, to: i, by: 1) {
          print(j, separator: "", terminator: "")
    }
    print("*\n")
}

//Create a swift array and print whole array using swift while loop only.
var primes:[Int] = [2, 3, 5, 7, 11]
 
for prime in primes {
    print("\(prime)")
}


//Create a swift program to show the capitals of different cities using Enumerations.
enum Climate {
   case India
   case America
   case Africa
   case Australia
}

var season = Climate.America
season = .America
switch season {
   case .India:
      print("Climate is Hot")
   case .America:
      print("Climate is Cold")
   case .Africa:
      print("Climate is Moderate")
   case .Australia:
      print("Climate is Rainy")
}

//Create a swift program to store the values of following students using Dictionary.
var numbers = [1: "One", 2: "Two", 3: "Three"]
print(numbers)


//Write a swift program to create calculator functions such as division, multiplication with return type
struct calcFuncs {
  var add : String
  var subtract : String
  var divide : String
  var multiply : String
}
  var calc = calcFuncs(add: "+", subtract: "-", divide: "/", multiply: "x")


//Write a swift program to create function with return value for wishing good morning. 
func greeting() {  
    print("Good Morning Everyone")  
}  
greeting()  


//Write a swift program to number is positive or negative or zero.
const positive = 5;
const negative = -5;
const zero = 0;

Math.sign(positive); // 1
Math.sign(negative); // -1
Math.sign(zero); // 0
//Create a swift array and print whole array using swift while loop.ss
var primes:[Int] = [2, 3, 5, 7, 11]
 
for prime in primes {
    print("\(prime)")
}


